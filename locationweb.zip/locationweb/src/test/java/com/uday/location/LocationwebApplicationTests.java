package com.uday.location;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
