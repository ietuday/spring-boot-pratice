package com.uday.location.repos;

import com.uday.location.entities.Location;

import org.springframework.data.jpa.repository.JpaRepository;


public class LocationRepository extends JpaRepository<Location, Integer> {
    
}